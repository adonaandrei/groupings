import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import Register from "./Register";
import Login from "./Login";
import Dashboard from "./Dashboard";
import Dashboard1 from "./Dashboard1";
import Dashboard2 from "./Dashboard2";
import Dashboard3 from "./Dashboard3";
import Dashboard4 from "./Dashboard4";
import Dashboard5 from "./Dashboard5";
import Dashboard6 from "./Dashboard6";
import Dashboard7 from "./Dashboard7";

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Register />} />
        <Route path="/login" element={<Login />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/staff" element={<Dashboard1 />} />
        <Route path="/staff2" element={<Dashboard2 />} />
        <Route path="/itfield" element={<Dashboard3 />} />
        <Route path="/itfield2" element={<Dashboard4 />} />
        <Route path="/itfield3" element={<Dashboard5 />} />
        <Route path="/itfield4" element={<Dashboard6 />} />
        <Route path="/itfield5" element={<Dashboard7 />} />
      </Routes>
    </Router>
  );
}

export default App;